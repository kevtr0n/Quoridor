package Players.DummyPlayer;
 
import Engine.Logger;
import Interface.Coordinate;
import Interface.PlayerModule;
import Interface.PlayerMove;
 
import java.util.*;
 
public class DummyPlayer   implements PlayerModule {
 
    private int myPlayerId;
    private Coordinate myPlayerLocation;
 
    // @Override
    public void init(Logger logger, int playerId, int numWalls, Map<Integer,Coordinate> playerHomes) {
 
        System.out.println ( "HELLO WORLD, we are now in the init method" +
                ", Java version is " + System.getProperty("java.version") );
 
        myPlayerId = playerId;
 
        /** determine the Coordinate location of my player's starting position */
        for ( Integer i : (Set<Integer>) playerHomes.keySet() ) {
            if ( i == myPlayerId )
                myPlayerLocation =  playerHomes.get(i);
        }
    }
 
 
    /**  Every time a valid move is made in the game, either by my player, or some other Player
     *   in the game (or via the list of PRE_MOVE's in the config file), the engine calls this method
     *   so that this Player can update the state of the game.
     *   The engine will verify that the move is a valid/legal move in Parts 1 and 2, but in Part 3, this
     *   method must check that the move is valid, and if not, then invalidate that player
     */
    @Override
    public void lastMove(PlayerMove m) {
    }
 
    @Override
    public void playerInvalidated(int playerId) {
    }
 
    /** Leave this method stubbed out for Part 1 */
    @Override
    public PlayerMove move() {
 
        /** This is sample code for a very, very simple Player Strategy
         *  This strategy will always move the Pawn up from its current position,
         *  without paying any attention to the Walls or other Pawn */
 
        int row = myPlayerLocation.getRow();
        int col = myPlayerLocation.getCol();
 
        Coordinate newPlayerLocation = new Coordinate( row - 1, col );
 
        PlayerMove myMove = new PlayerMove(myPlayerId, true, myPlayerLocation, newPlayerLocation);
         
        myPlayerLocation = newPlayerLocation;
 
        return myMove;
    }
 
    @Override
    public int getID() {
        return myPlayerId;
    }
 
    @Override
    public Set getNeighbors(Coordinate c) {
        return null;   
    }
 
 
    @Override
    public List getShortestPath(Coordinate start, Coordinate end) {
        return null;  
    }
 
 
    @Override
    public int getWallsRemaining(int playerId) {
        return 0;
    }
 
 
    @Override
    public Coordinate getPlayerLocation(int playerId) {
        return myPlayerLocation;
    }
 
 
    @Override
    public Map getPlayerLocations() {
        return null;
    }
 
 
    /**
     * This method should return a Set containing all the possible games
     * moves for the Player.
     * 
     * Here we simply create a "bogus" Set that contains only 1 move, which
     * is the move that makes our Pawn move one row up 
     */
    @Override
    public Set allPossibleMoves() {
         
        int row = myPlayerLocation.getRow();
        int col = myPlayerLocation.getCol();
        Coordinate newPlayerLocation = new Coordinate( row - 1, col );
         
        PlayerMove completelyBogusMove = new PlayerMove(myPlayerId, true, myPlayerLocation, newPlayerLocation);
         
        Set allMovesInGame = new HashSet();
         
        allMovesInGame.add( completelyBogusMove );
         
        return allMovesInGame;
    }
}